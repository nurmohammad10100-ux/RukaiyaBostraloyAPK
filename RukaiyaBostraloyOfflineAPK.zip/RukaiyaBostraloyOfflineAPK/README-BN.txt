রুকাইয়া বস্ত্রালয় — Offline Android APK project

এই প্রকল্পে মূল HTML অ্যাপটি assets/index.html হিসেবে রাখা হয়েছে।
- Internet ছাড়াই হিসাব/গ্রাহক/লেনদেনের localStorage ডেটা চলবে।
- Google Font dependency সরানো হয়েছে।
- বাংলাদেশ সময় অনুযায়ী backup filename-এর তারিখ ঠিক করা হয়েছে।
- Android APK-তে JSON backup Downloads ফোল্ডারে সেভ করার native bridge আছে।
- Gmail/Email পাঠানো স্বভাবতই Internet চাইবে; offline অবস্থায় অ্যাপ backup ফাইল সেভ করবে কিন্তু ইমেইল পাঠাবে না।

Android Studio-তে খুলে Build > Build APK(s) করলে APK তৈরি হবে।
অথবা GitHub-এ আপলোড করে Actions > Build APK চালানো যাবে।
